# Waluipedia Mass Import / Export (Foundry VTT module)

One click exports **every actor in the world, with folders** — to one JSON
file, or **into your Foundry Data folder as a tree** (one file per actor,
subfolders = your Actors folders, plus `import.json`). One click imports back
from a file, a URL, a repo packet, **or a whole directory inside Data**
(subfolders detected and used as the folders) — a **review table** first
(untick, rename, move folders), then folders created, missing actors created,
existing ones updated in place (same `_id`), every image path checked, and a
report. Together with `tools/foundry-bridge.py` this turns "add characters to
the game" into a loop of *export → edit in the repo → import*.

Module id: `waluipedia-mass-import`, version 1.8.1. Core v12–v14, any game
system (built and tested against dnd5e 5.x on core v14).

## 1.8 — one copy of the art: Foundry loads it from the archive's own server

Every portrait, token plate and repo item icon used to be copied into Foundry's
Data folder (`portraits/…`, `assets/images/…`) — the same bytes as the repo,
twice on the GM's disk, and once more per machine. From 1.8 the packets name
that art by **URL on the archive's own server** (`start.py`, the suite's
`--art-base`; e.g. `http://100.64.0.9:8765/Reputation-Matrix2/portraits/player/fullbody/remi.png`).
Foundry's `img` and `texture.src` take absolute URLs as they are; `start.py`
answers with `Access-Control-Allow-Origin: *`, which the canvas needs for token
textures. The live players' own uploads (`npc/…`, `player/…`) are untouched.

| Now | How |
| --- | --- |
| **Placed tokens follow.** | A token dropped on a scene copies its prototype's texture path at that moment. When an update moves an actor's prototype token from the Data path to the URL, every placed token of that actor still showing the old path is re-pointed (`N placed tokens re-pointed` in the summary; nothing in a dry run). |
| **The export back lists what the world uses.** | `imagesInUse`: scene backgrounds, placed tokens, tiles, journal images (pages and `<img>` in text), world items, macros, actors. `tools/foundry-bridge.py prune-images` deletes a Data copy only when the repo has the identical bytes, the server returns those very bytes, the newest export back does not reference the Data path, and no packet does — otherwise it keeps the file and says why. An export back from before 1.8 (no list) vouches for nothing: nothing is deleted. |
| **A client that cannot reach the art says so.** | `packets.json` carries `artBase` + `artProbe`; at load the GM's sync HEADs the probe, and so does each player's browser. A yellow toast once per load: *start.py is not answering at … — start it (start.bat) and keep it open whenever Foundry is*; for a player: *ask the GM*; and when the packets point at `127.0.0.1` but the client is elsewhere: *tick "reachable from other machines" in start.py*. |

What this costs: **start.py must run whenever Foundry is open** (the GM's
`start.bat`), and for players on other machines it must be exposed on an
address they reach (the launcher's *reachable from other machines* tick picks
the Tailscale address, else the LAN one). The old behaviour is one flag away:
`start.py --art-base copy` / `sheets-suite.py --art-copy` copies the art into
Data again and the packets go back to Data paths.

## 1.7.1 — the spoils arrive, the export says what was applied, the Foundry-only GM is told

Three small things, all on the record's side of the loop:

| Now | How |
| --- | --- |
| **The record's loot reaches the sheet.** | Filing an event now registers what was picked up in `Reputation-Matrix2/data/inventory.json`; `tools/spoils-to-changes.py` turns the holdings the exported sheets lack into `actors/changes/spoils-<world>.json`, the suite applies it, the packet carries the items, and the Sync shows them as changed rows — `Hjumpik Deldkur — + Mystic Morel's Feyward Key, Steely's Rusted Fragments, The OC Soul Ring, The Raventree Signet Ring, …` — and asks first, as always. Each item carries `flags.waluipedia.inventoryItem`, so the next export tells the tool the table has it. |
| **The export back says what was applied.** | After a real apply the world remembers `{stamp, at, exportedAt}` of that packet (`syncLastApplied`), and every export back carries it as `lastSync.applied` next to `exportedBy`. The suite keeps it in `manifest.json`; the spoils tool uses it to tell *the table removed this item after seeing it* (declined — not offered again) from *the packet never got there* (offered again). |
| **A GM who only ever runs Foundry hears about it.** | The module works without the suite: the packet comes from GitHub, Sync asks first, the table's newer actors are kept. What breaks silently is the other direction — the world exports itself back into `Data/npc/waluipedia/<world>/export/`, and nothing reads it. At world load the module compares its last export back with the export the packet in front of it was built from (`packets.json` / `manifest.json` `exportedAt`); an unread export older than a day is a yellow toast once per load: *N day(s) of table changes unread by Waluipedia — run start.py (or tools/sheets-suite.py) on the archive side*; younger ones are a console line. Nothing is lost meanwhile — the export waits where it was written. |

## 1.7 — ask first, keep what the table changed, flow back, update itself

The first run of 1.6 code did what 1.5 was meant to do — and the console
showed what was still wrong: `0 created, 329 updated`, four "repaired" items
that were in fact **deleted** (Eager's Toad species and Catastrophe Scout
background, Dan's Toad species — `Cannot read properties of undefined
(reading '_source')`, then `Only a single Species can be added`), a warning
that read *1.5.0 is installed but still runs 1.6.0*, and a packet that would
have been applied over a session's changes without a word.

| Now | How |
| --- | --- |
| **Sync asks before it writes.** | Every sync — automatic at world load or the Sync button — is first run as a **dry run** against the live world (nothing written; the diff is the exact one the import would send). Nothing pending → `the world already matches the packet — nothing to do`, the packet's stamp is remembered, and the automatic sync stays silent until the packet changes. Something pending → the summary opens as a question, **Apply** / **Not now** / **Skip this packet**: *Not now* asks again next load, *Skip* is quiet until the next packet, *Apply* runs the real import. Setting *Ask before applying* (on). |
| **The table wins.** | An actor whose `_stats.modifiedTime` in the world is **newer than its copy in the packet** (Foundry stamps every write; the packet carries the export's stamps, else its `exportedAt`) is **kept**: its differences are listed under *Kept — the world is newer than the packet*, nothing is written, no question is raised for it. After the session's export flows back (below) and the suite rebuilds the packet, the stamps agree and the packet applies again. Option `preferNewer` (on). |
| **Changed means changed.** | `N changed (M unchanged)`: an actor counts as changed only when a write went out; the 329 of the 1.6 run were 148 overlay writes (tags, colours, folder paths, the ledger block, five XP values, two item repairs) — the second pass over the same world now reports `0 changed (329 unchanged)`. Every changed row says why (`XP 6500 → 14000`, `HP 31 → 30`, `+ The Electric Sphere [loot]`, `− Dagger [weapon]`, `moved to Players`, and `fields: …` only for what those lines do not explain). |
| **Invalid items are repaired, never lost.** | A broken embedded item (`items.get(id)` undefined, `invalidDocumentIds`) is repaired the way dnd5e's own migration does it — **through the parent**: `actor.update({items:[{_id, …}]})`. When that still throws, a species or background (dnd5e singletons) is **never deleted** unless its replacement is guaranteed: with a stand-in already on the sheet the item is left alone and the summary offers a one-click **swap** (`Use Toad — Eager Variant instead of Grung`); alone, it is recreated under a fresh id first and the broken one removed after. Other item types keep the delete + recreate under the same id. If Foundry's in-memory copy still lists the id as invalid after the database write, the summary says *repaired in the database — reload (F5)* instead of trying again. |
| **The world flows back.** | The active GM's client exports the whole world — same file as *Mass export* — to `<Data>/npc/waluipedia/<world>/export/<world>-all-actors.json` two minutes after the last change to any world actor, item or effect (setting *Export back*, on; *Export delay*, 120 s). `tools/sheets-suite.py --watch` reads that folder like Downloads: newer export → split into the world mirror, player sheets rebuilt at ledger XP, `data/sheets.json`, a new packet published — and the next Sync has nothing to do. |
| **GitHub, both ways.** | `tools/sheets-suite.py --git-sync` (start.py: *Two-way with GitHub*): before a pass `git pull --ff-only` when the checkout is clean and behind (a refused pull says why — uncommitted changes outside the suite's own files are never clobbered; the suite's own earlier commits are rebased); after a pass the suite commits what it wrote (`Reputation-Matrix2/actors/worlds/<world>`, `actors/cast`, `data/sheets.json`, the root `<world>-all-actors.json`) as `sheets-suite: <world> mirror from export <stamp> — N file(s)` and pushes to the tracked branch; under `--watch` GitHub is polled every `--git-interval` seconds (300) and a pass runs when something was pulled. A push that fails is reported and retried next pass; nothing in it is fatal. |
| **The module updates itself.** | The pull brings the new module into the checkout, the pass installs it into `Data/modules/`, and the 1.6 loader runs it after a plain F5. At `ready` the module also asks GitHub for the branch's `module.json` (`raw.githubusercontent` answers cross-origin): when GitHub is ahead a blue toast and a line in the summary say so (*GitHub (gh-pages) has module 1.8.0; this install runs 1.7.0 — the suite with --git-sync installs it*). |
| **The version words are right.** | `versionVerdict`: *1.7.0 is installed but this world still runs 1.6.0 — Setup → Launch World* only when the disk is **ahead** of the code; when the disk is **behind** (what the 1.6 run saw: `module.json` 1.5.0, code 1.6.0) it says the install is half-updated or Foundry reads another Data folder, and names the suite; a manifest loaded older than the code is a console note. |

Not changed on purpose: a level-up is **never** applied by the sync — the
ledger's XP goes onto the sheet (`XP 14000 → 23000`), the summary shows the
**⬆ Level up at the table** banner, and the character's level, hit dice,
features and spell slots stay for dnd5e's own level-up at the table; the
next export carries the new level back.

## 1.6 — the world was running 1.2.0 the whole time

Three installs (1.3, 1.4, 1.5) and three runs that still printed `2 FAILED`,
`Only a single Species…`, `%252B` image paths and the v12 progress bar. The
console told on itself: `mass-import.js:949 [waluipedia-mass-import] ready`,
`progress (mass-import.js:616)`, `openImportDialog (mass-import.js:857)` —
**those are 1.2.0's line numbers**, the last version with no Sync button
(hence *Mass import → file picker* every time). The script on disk had moved
on; the one in the browser had not. Foundry hands the browser
`scripts/mass-import.js?v=<version in the manifest it read at world launch>`,
the browser keeps that file for as long as its cache allows, and a plain F5
revalidates the page, not the module. So a new copy under `Data/modules/`
only runs after **Return to Setup → Launch World** (new `?v=`) **and** a
hard reload — and nobody had done both.

| Now | How |
| --- | --- |
| **A newer install runs after a plain F5.** | `scripts/mass-import.js` is a 20-line **loader** that never changes; it imports `scripts/mass-import-core.js?v=<now>` — a fresh query string on every load, so the browser cannot serve a stale core and the server's manifest version does not matter. The loader registers `init` / `ready` / `renderActorDirectory` synchronously and hands each to the core when it arrives. |
| **The console says which version runs.** | First module line: `[waluipedia-mass-import] 1.6.0 ready`. When Foundry's manifest is older than the code running it adds *(Foundry loaded the manifest of 1.2.0 — Setup → Launch World refreshes it)* and links a fresh copy of the stylesheet so the summary looks right; when `module.json` on disk is **newer** than the code running (impossible from 1.6 on unless the loader itself was cached) the GM gets an orange warning at `ready`: *Setup → Launch World, then Ctrl+F5*. |
| **The suite asks Foundry what it serves.** | After installing, `tools/sheets-suite.py` fetches `modules/waluipedia-mass-import/module.json` from the running server (`Config/options.json`'s port, default 30000, or `--foundry-url`) and prints one line: *serves 1.6.0 (the copy just installed) — relaunch the world if the console does not say so* / *serves 1.2.0, NOT the 1.6.0 just written to `<Data>` — Foundry reads a different Data folder; Setup → Configuration shows the User Data Path; `--foundry-data "<that path>\Data"`* / *no modules/waluipedia-mass-import on that server* / *no Foundry server answered*. |

**Once, to get from the cached 1.2.0 to 1.6:** run the suite (start.py does),
read its `foundry :` line, then in Foundry **Game Settings → Return to Setup →
Launch World**, and on the game page **Ctrl+F5** (Foundry app: F12 → Network →
tick *Disable cache* → F5). The console must open with
`[waluipedia-mass-import] 1.6.0 ready`; from then on a plain F5 is enough.

To see what the server serves without the suite: open
`http://localhost:30000/modules/waluipedia-mass-import/module.json` in a tab.

## 1.5 — one packet, by itself, no FAILED actors, no leftover folders

The second Sync printed `0 created, 149 updated, 2 FAILED, 22 folders` with a
console full of `Item "X" does not exist!`, `Only a single Species can be
added to a Player Character.` and `The _id [...] already exists within the
parent collection`. 1.5 answers it the same way 1.4 answered the first one:

| What you saw | Why | Now |
| --- | --- | --- |
| **Which packet?** `players` / `world` / `cast`, three files, 955 BF separate | Scopes. | **Gone.** There is **one packet** — `npc/waluipedia/<world>/import.json`, written by the suite from the world mirror → the generated cast → the 955 BF court (329 actors, 32 coloured folders for *midlands*; a name that is in the world already is not brought in a second time). Sync has nothing to choose and no file to pick; the GitHub fallback fetches the manifest, the cast and the court and merges them the same way. |
| You have to click | — | **Sync runs by itself when the world loads** (GMs only, setting *Sync by itself*), a few seconds after `ready`, and only when the published packet changed since the last run — otherwise it does nothing and says nothing. The button and the macro still work; the summary opens when something was created, changed, repaired, noted or tidied. |
| `2 FAILED` — Eager (`VudZ3W313Y4FILs0`), Feyward Dan (`IlzuThuR8upTtqtF`): `The _id [218ad632c6e149d9] already exists within the parent collection` | Their world copies hold **invalid embedded documents** — the home-made Toad species, a background, a feat, two pieces of clothing whose identifiers dnd5e refuses. Foundry keeps those out of `actor.items` (they only exist in the source and `invalidDocumentIds`), so the diff never saw them, tried to *create* the repaired copies under the same ids, and the server threw. | The sync reads the **source**, invalid documents included, and **repairs an invalid document with an update** (which dnd5e accepts); if that is refused too it is deleted and created again under its own id. Reported as *n broken items repaired*. |
| `Only a single Species can be added to a Player Character.` / `… Background …` | Creating a species while the sheet already has one (the Grung / Slave stand-ins the players dropped in while the Toad was broken) is refused by dnd5e — silently, the create resolves without the document. | Repairs go through updates, so this no longer happens for the broken Toads. When a packet really does bring a *second* species/background the refusal is a **note for the GM** (`Notes for the GM` in the summary), never a failure. The summary also lists sheets that end up with two species or two backgrounds — *keep one, delete the stand-in* — until you do. |
| `Item "VfJl4waJI38BhqP4" does not exist!` × many | The cached copies of Cast-activity spells (`flags.dnd5e.cachedFor`). dnd5e deletes and recreates them whenever a Cast item is touched; the sync was still comparing them and sometimes writing them while the system did the same. | **Cached spells are never written** — excluded on both sides of the diff; an item whose activities change is still updated in a call of its own. |
| Empty folders, a folder with one creature | 1.3 made its own `Players`, `Koopa Troop`… beside yours; after 1.4 moved the actors into the website layout the old ones stayed behind, empty. | **Folder tidy after every sync**: folders with the same name under the same parent (trimmed, case-insensitive) are **merged** into the fuller one (colour carried over), then **empty folders are removed** bottom-up. Settings *Merge duplicate folders* / *Remove empty folders*. Folders with a single creature are not made in the first place — the organizer files singletons under *Elsewhere* and only opens *Bestiary / ⟨type⟩* for two or more. |
| 1.4 installed, yet the second sync behaved like 1.3 | Foundry loads module code at world launch; the suite's install lands on disk while the world is open. | The summary names the **running** module version and the one **on disk**; when they differ it says so in orange: *Setup → relaunch the world (then Ctrl+F5)*. |

## 1.4 — clean syncs, folders like the website, tags

The first full-world Sync of the midlands world worked but was noisy; 1.4
answers every line of that console:

| What you saw | Why | Now |
| --- | --- | --- |
| `Item "X" does not exist!` (uncaught, dozens of times, from `item.mjs:1151`) | Updates were sent as whole documents (`diff: false`). To dnd5e every item then looked like a change to its activities; the system deleted and recreated every cached Cast spell, and because it notes those ids on the *shared* batch options, every other item in the batch tried to delete the same ids again. | Updates are **diffs**: an actor or item identical to the packet is not written at all; only the fields that differ are sent; `flags`, `ownership` and dnd5e's activities map get real `-=key` deletions; an item whose activities change is updated in a call of its own; the cached spells of a Cast item that is itself being deleted are left to the system. A second Sync of the same packet writes nothing and says `(151 unchanged)`. |
| `Invalid embedded document data` / `identifier … may only contain …` on actors `VudZ3W313Y4FILs0` (Eager) and `IlzuThuR8upTtqtF` (Feyward Dan) | The players' own exports carried identifiers like `toad-—-eager-variant`, `disaster-inc.-catastrophe-scout`, `dead-person's-shoes`; dnd5e refuses them, the item becomes invisible on the sheet and the world logs it on every load. | `tools/foundry-bridge.py split` repairs them in the mirror (`toad-eager-variant`), `check` fails on any that remain, the intake sanitizer fixes them before they ever reach a packet, and the module slugifies whatever still arrives — reported under **Repaired identifiers**. One Sync and the errors stop. |
| `SceneNavigation.displayProgressBar is deprecated` | The v12 progress bar. | `ui.notifications.info(…, {progress: true})` with `.update()` on v13+; the old bar only on v12. |
| 404 for `npc/MLSS%252BBM_Art_-_Fawful.png` | Foundry stores image paths already URL-encoded; the check encoded them again. | Encoded once. Wildcard token paths (`guard*.webp`, `{a,b}.webp`) are not checked at all. The remaining "missing images" are real: bare file names and `modules/house-divided/…` paths from someone else's Data folder. |
| Everything in 13 folders, 45 actors at the root | The packet mirrored the world as it was. | The suite's **organize** step (`tools/organize-actors.py`, rules in `actors/folders.json`) files every actor the way the website's `#/sheets` page does — *Players*, one folder per website group, *Bestiary / ⟨creature type⟩* — and the packet carries the **folder colours** (the site's faction colours). New folders are born coloured; your existing colourless folders are painted; a folder you coloured yourself keeps its colour. |
| No way to see what an actor *is* from the sidebar | — | **Tags.** The organizer writes `flags["waluipedia-sheets"].tags` (website group, `pc`/`npc`, role, creature type, the folder it came from) and the module shows them as chips next to the name in the Actors sidebar, tinted with the folder colour. Client setting *Tag chips in the Actors sidebar* switches them off. |

The Sync summary gained **Repaired identifiers** and a **Folders** section
(folder → how many of the synced actors live there, which are new, which were
coloured).

## Sync — everything, by itself (v1.5; one click since v1.3)

**It runs on its own.** When a GM loads the world the module waits a few
seconds, looks for the published packet and, if it is not the one it synced
last time, imports it and opens the summary. Same packet as last time:
nothing happens, nothing is printed. **Actors sidebar → Sync** does the same
thing right now (Shift-click = review table first). No file to pick, no URL
to paste, no scope to choose: one packet carries **everything** — the world
mirror, the generated cast, the 955 BF court — in the website's coloured
folders. It looks in three places, in this order, and uses the first that
answers:

| # | Where | What it reads | When it is there |
| --- | --- | --- | --- |
| 1 | **your Foundry Data folder** — `npc/waluipedia/<world>/import.json` (+ `packets.json` for the digest) | the one packet the suite published | after `start.py` / `tools/sheets-suite.py` ran on this machine (it finds the Data folder itself — `--foundry-data` overrides) |
| 2 | **the launcher** — `http://127.0.0.1:8765/Reputation-Matrix2/actors/worlds/<world>/import.json` | the same packet straight from the checkout | while `start.py` is running |
| 3 | **GitHub** — `raw.githubusercontent.com/mikegent01/bik/<branch>/…/worlds/<world>/manifest.json` + the actor files it lists, `…/actors/cast/import.json`, `…/actors/peachs-castle-955/import.json`, merged in that order (first by `_id`, then by name + type) | the committed sheets | always, once the branch is merged (the packet itself is not committed; the manifest + per-actor files and the cast/court packets are) |

Then it does what Mass import does — folders from the packet's `folderPath`
(an existing folder with the same name under the same parent is reused,
case-insensitively), missing actors created, existing ones updated in place
by id as **diffs**, invalid embedded documents **repaired**, an NPC statblock
**replaced by the character sheet under the same id** when the type changed
(ownership kept) — then **tidies the folders** (duplicates merged, empty ones
removed) and ends with a **summary**: replaced / changed / new / unchanged,
per actor the XP change, the class line, items gained (`+ The Electric
Sphere`) or lost, folder moves, a **⬆ Level up at the table** banner when the
ledger is ahead of the sheet, *Notes for the GM*, the folders touched, the
module version running vs on disk, and *where it looked*. The same summary is
whispered to the GMs in chat (one message per sync; not on dry runs).

* **Settings** (Module Settings): *Sync by itself* (on), world (`midlands`),
  packet dir in Data (`npc/waluipedia`), launcher URL, GitHub branch
  (`gh-pages`), *Merge duplicate folders* (on), *Remove empty folders* (on),
  review-first (off), *Ask before applying* (on, 1.7), *Export back* (on,
  1.7) with its delay (120 s).
* If nothing answers, Sync changes nothing and shows the URLs it tried
  with the error for each and what to run (`start.py`, or
  `python3 tools/sheets-suite.py --foundry-data "<Data>"`); when it ran by
  itself it stays silent.
* Wrong file in **Mass import** (the site's `data/sheets.json`, or a
  `manifest.json`) is refused with a message that names the right file
  instead of an uncaught error.
* After the suite installs a new module version a plain **F5** runs it
  (1.6 loader); a world still on a 1.5-or-older script needs **Return to
  Setup → Launch World, then Ctrl+F5** once — the summary and the console
  tell you when the code running is older than the code on disk.
* Macro: `macros/sync-from-waluipedia.js` (`REVIEW` at the top); API:
  `game.modules.get("waluipedia-mass-import").api.syncFromWaluipedia({ world, review, options })`.

## Where the import-all files are

The repo ships ready-made packets. In the Import dialog they are in the
**Repo packet** dropdown; pasting the raw URL does the same thing.

| Packet | File in the repo | Raw URL (paste into *URL / Data path*) |
| --- | --- | --- |
| **Waluipedia Cast** — every generated character sheet (152: 118 NPCs and 34 main-cast player characters, plus the past selves under *<group> / 955 BF*; folders *Waluipedia Cast / <group>*) | `Reputation-Matrix2/actors/cast/import.json` | `https://raw.githubusercontent.com/mikegent01/bik/gh-pages/Reputation-Matrix2/actors/cast/import.json` |
| **Peach's Castle 955 BF** — the court + Bowser's incursion (30) | `Reputation-Matrix2/actors/peachs-castle-955/import.json` | `https://raw.githubusercontent.com/mikegent01/bik/gh-pages/Reputation-Matrix2/actors/peachs-castle-955/import.json` |
| **Bowser's Castle 1035 BF** — Bowser's line, Fawthful's forces, the remnant at the track (27) | `Reputation-Matrix2/actors/bowsers-castle-1035/import.json` | `https://raw.githubusercontent.com/mikegent01/bik/gh-pages/Reputation-Matrix2/actors/bowsers-castle-1035/import.json` |
| **Your live world** (`midlands`) — split one file per actor | `Reputation-Matrix2/actors/worlds/midlands/` (a directory, no single file) | import it **as a directory**: link the repo into Data with `python3 tools/foundry-studio.py link` and give the dialog `npc/waluipedia/actors/worlds/midlands` |
| One character | any `fvtt-Actor-*.json` — also the *Download Foundry JSON* button on `#/sheets/<id>` | the sheet page prints its own *Mass Import URL* |

A single file is still the easiest hand-off (one URL, one click), but it is no
longer the only way in: **any directory of actor files works**, and the
Export dialog can write such a directory for you.

## Install

**Manifest URL** (Foundry → Add-on Modules → Install Module → paste at the bottom):

```
https://mikegent01.github.io/bik/Reputation-Matrix2/Foundry/mass_import/module.json
```

The zip it points to is `Reputation-Matrix2/Foundry/mass_import.zip`, rebuilt by
`python3 tools/build-foundry-module-zip.py` whenever the module sources change
(`check-all.py` fails if it is stale). Offline alternative: copy the
`mass_import/` folder to `<FoundryData>/Data/modules/waluipedia-mass-import/`
— which is what `tools/sheets-suite.py` (and so `start.py`) does on every pass,
into the Data folder it finds (`--foundry-data` to point it elsewhere); it then
asks the running Foundry server which version it serves and says whether that
is the folder Foundry reads.

Enable it in **Game Settings → Manage Modules**. Only GMs see or can use it.

## Buttons

In the **Actors** sidebar header, next to "Create Actor":

| Button | What it does |
| --- | --- |
| **Sync** | Runs by itself when the world loads; the button does it now: find the published packet (Data folder → launcher → GitHub), import everything into coloured folders, repair, tidy folders, summary. Shift-click = review table first. See *Sync — everything, by itself* above. |
| **Mass export** | Dialog: optional folder subtree, optional type filter (character/npc/vehicle/group), and a **destination**: *Download one JSON* (`<world>-all-actors.json`) or *Write into the Foundry Data folder* — a tree under `npc/waluipedia/<world>/` with one file per actor in subfolders mirroring your Actors sidebar, plus `import.json` with everything. |
| **Mass import** | Dialog: source = **JSON file** from disk, a **repo packet** from the dropdown, a **URL** (GitHub raw works — CORS is open there), or **a path inside your Foundry Data folder** — either one `.json` or **a directory** (📁 button browses; every `.json` under it is read, **subfolders are detected** and become the Actors folders). Then the **review table**. Options below. Prints a report afterwards and logs the full result object to the console. |

### The review table (the visualizer)

With *review first* ticked (default) nothing changes until you have seen the
list: one row per actor with a checkbox, an editable **name**, the type, an
editable **folder** (`A / B` nests) and what will happen — **new** or
**update** (the existing actor's name is shown when it differs). Tools above
the table act on the visible rows: a filter box, *all* / *none* / *only new* /
*only updates*, and a folder box with **set folder** (replace the ticked rows'
folders) and **prefix** (put the ticked rows' folders under it). Files that are
not actors (`manifest.json`, notes) are listed as ignored. *Import ticked*
imports exactly what the table shows.

### Directories and folders

When the source is a directory, **Directory folders** decides what the folder
of each actor is:

| Setting | Rule |
| --- | --- |
| *subfolders are the Actors folders* (default) | the subdirectory chain under the directory you chose **is** the folder path — move a file to another subdirectory and the actor moves folder on the next import. A combined `import.json` sitting inside a subdirectory keeps its own paths **under** that subdirectory. |
| *trust each file's own folder path* | the file's `flags.waluipedia-mass-import.folderPath` wins; the subdirectory only fills in when a file has none (the rule `tools/foundry-bridge.py combine` uses). |

Either way *Put everything under* prefixes the result, and the review table
lets you override any row.

The import source box is pre-filled from the world setting **Default import
source** (Configure Settings → Module Settings), so a recurring import is
"Import → Run".

### Import options

| Option | Default | Meaning |
| --- | --- | --- |
| Mode | upsert | `upsert` creates missing actors and updates existing ones; `create` never touches existing actors; `update` never creates. |
| Keep ids | on | New actors are created with the `_id` from the file, so the next import finds them again. Turn off only if you *want* duplicates. |
| Match by name + type | on | Actors without an id (or whose id is not in the world) are matched by `name` + `type` before being created — but never to an actor that is itself part of the same import, so two different "Guard" statblocks in one export stay two actors. |
| Replace embedded | on | Items and active effects are synced to the file: same `_id` → update, new → create, missing from the file → **deleted**. Off = only create/update, never delete. |
| Replace on type change | on | An actor whose `_id` exists in the world with a **different type** (an NPC statblock that became a `character` sheet, say) cannot be updated in place — Foundry never changes a document's type. The module deletes it and recreates it **under the same id**, keeping the world's folder and ownership and merging flags, so tokens, journal links and player access keep resolving. The review table shows these rows as `replace (npc → character)`. Off = such rows are skipped and reported. |
| Overwrite ownership | off | Keep the world's permission settings on existing actors (and on replacements). |
| Skip player characters | off | Leave `type: character` actors alone (handy when a packet of NPCs happens to include PCs). |
| Check images | on | `HEAD`-requests every `img` / token / item image path and lists the ones the server does not have. |
| Fix missing images | off | Replace missing image paths with Foundry's placeholders (`icons/svg/mystery-man.svg` / `icons/svg/item-bag.svg`) instead of importing broken links. |
| Colour folders | on (API `colorFolders`) | New folders take the colour / description the packet carries (`folders[].color`, `folderStyles`); existing folders with no colour are painted; a folder you coloured yourself is never changed. |
| Repair identifiers | on (API `repairIdentifiers`) | Item identifiers dnd5e would reject are slugified on the way in and listed in the report. |
| Root folder | empty | Prefix for every folder path, e.g. `Imports / Session 42` → `Imports / Session 42 / Peach's Castle 955 BF / The Court`. |
| Review first | on | Show the review table before importing (see above). Off = import straight away, as 1.0 did. |
| Dry run | off | Compute and report everything, change nothing. |

### Folders

Foundry's `toObject()` only stores a folder **id**, which means nothing in another
world. This module stores the **path** instead, in
`flags["waluipedia-mass-import"].folderPath` (an array of names, e.g.
`["Peach's Castle 955 BF", "The Court"]`), and also ships a `folders` list in the
export. On import the chain is created on demand (existing folders with the same
name under the same parent are reused). Old exports that only have `folder` ids
still work: with a matching `folders` list the path is resolved; without one
(the old macro export) the folder is *unknown*, so an existing actor **keeps
the folder it is in**, and a new actor goes into that folder if this world has
it (same-world re-import) or into the root / "Root folder" otherwise. Nothing is
ever moved to the root just because the file did not say where it belongs.

## Accepted import shapes

1. This module's export: `{ format: "waluipedia-actors/1", exportedFrom, system, folders, actors }`
2. The old macro export: `{ exportedFrom, system, exportedAt, actors }`
3. A bare array of actors (what `Players.json` in the repo is)
4. A single actor JSON (a `fvtt-Actor-*.json` file)

Refused with a plain message (nothing happens): the site's `data/sheets.json`
(the sheet *index* — use Sync, or `players-import.json`), and a
`manifest.json` (a *list* of files — give its URL or Data path instead and
the module fetches the files it names).

## Update semantics (read this once)

Updating an existing actor sends **the difference** between the world's
document and the file (`docDiff` in the API): nothing at all when they agree,
otherwise only the fields that differ — the file is the source of truth, so a
hit-point change made in Foundry after the export is still overwritten if the
file has the old value (export first, edit, import), but an untouched actor
costs no database write, no hooks, no activity churn. Keys the file does not
have are left alone, except in the free-form maps where "missing" means
"removed": `flags`, `ownership`, dnd5e's `system.activities` and the actor's
`system.tools` get `-=key` deletions. Items and effects follow the same rule
(same `_id` → diff, new → create, missing → delete). Exceptions: `flags` are
merged (other modules' flags survive), `ownership` is kept unless "Overwrite
ownership" is ticked, `_stats` is never written. A type change (`npc` → `character`) is the one thing an
update cannot express: with "Replace on type change" on (the default) the
actor is deleted and recreated under the same `_id`, with the world's folder,
ownership and other modules' flags carried over; the report lists it under
"Replaced". Player characters that were run off NPC statblocks are promoted
this way — `tools/promote-player-sheets.py` writes the character sheets into
the world mirror, the next import swaps them in.

## Export into the Data folder, import it back

```
Mass export → destination “Write into the Foundry Data folder”
   Data/npc/waluipedia/<world>/
      import.json                                  everything, one file
      Peach's Castle 955 BF/The Court/fvtt-Actor-castle-page-<id>.json
      Disaster Inc./fvtt-Actor-remi-<id>.json
      fvtt-Actor-loose-npc-<id>.json               (root of the sidebar)

Mass import → URL / Data path = npc/waluipedia/<world>   (📁 picks it)
   every .json under it is read; the subdirectories are the folders again
```

The tree is plain files on your disk, so you can reorganise it in Explorer
(move a file = move the actor), hand it to `tools/foundry-bridge.py check /
combine / link-images`, or point `tools/foundry-studio.py` at it. Writing uses
Foundry's own upload API (`.json` is an allowed upload type), one request per
file; 150 actors take a few seconds.

## The art folder: `tools/foundry-studio.py` (Foundry++ character editor suite)

The portraits, tokens and cut-outs live in a folder that fills up faster than
it gets named — `bonesclean.webp`, `danm.png`, `court-mage-a.png`, a dozen
`<hash>-removebg-preview.png`. The studio (stdlib Python, runs on Windows as
`py tools\foundry-studio.py …`) turns that folder into a library Foundry can
address, and connects the repo's actor trees to the Data folder:

```bash
python3 tools/foundry-studio.py scan  <folder>              # what is loose, what the archive thinks each one is
python3 tools/foundry-studio.py sort  <folder>              # per file: name → kind → faction → version; files it
python3 tools/foundry-studio.py list  <folder> [--faction koopa_troop] [--kind tokens]
python3 tools/foundry-studio.py rename <folder> bear "Bear Guard"      # files follow the name
python3 tools/foundry-studio.py edit   <folder> bear_guard --faction iron_legion --character bowser --version 955-bf
python3 tools/foundry-studio.py delete <folder> bear_guard/portraits   # to _trash/ unless --forever
python3 tools/foundry-studio.py link   <folder> [--data "%LOCALAPPDATA%\FoundryVTT\Data"]
python3 tools/foundry-studio.py unlink
python3 tools/foundry-studio.py versions bowser [--stub 1000-bf]      # now, the past selves, a pasteable ERAS entry
python3 tools/foundry-studio.py adopt  <folder> bones                  # library portrait → Reputation-Matrix2/portraits/bones.webp
python3 tools/foundry-studio.py changes <folder> --out changes.json    # bridge `apply` file: img + token → the linked art
```

`sort` suggests names from `characters.json` and the 955 roster (`danm` → Dan
86 %, `court-chambermaid` → Castle Chambermaid), guesses the kind from the
folder or the name (`-removebg-preview` = token), defaults the faction from
the XP ledger, and moves each file to `<kind>/<faction>/<slug>[--<version>].<ext>`,
remembering everything in `foundry-studio.json`. Enter accepts, `s` skips, `d`
trashes, `q` stops; `--answers file.json` replaces the keyboard, `--auto` takes
only the sure suggestions (≥ 85 %).

`link` creates, inside Foundry's Data folder:

```
Data/npc/waluipedia/actors/…                      → Reputation-Matrix2/actors (the repo tree: cast/, worlds/midlands/, peachs-castle-955/)
Data/npc/waluipedia/art/<faction>/<slug>/portrait.png · token.webp · icon.png · bg.jpg · ai.png
Data/npc/waluipedia/audio/<faction>/<slug>.mp3
```

Symlinks where the OS allows them; on Windows a directory falls back to a
junction and a file to a hard link, then to a copy (`--copy` forces copies).
`studio-links.json` records what was made so `unlink` removes exactly that.
After `link`, the Import dialog's *Data path* `npc/waluipedia/actors/cast`
(or `…/worlds/midlands`) is a real directory, and `changes` writes the
`foundry-bridge.py apply` file that points each matching actor's `img` and
token at the linked art.

## API

New in 1.5: `autoSync({ delay })`, `mergePackets(list)`, `syncStamp(info, raw)`,
`checkModuleVersion()`, `tidyFolders({ merge, prune, dryRun, report })`,
`duplicateFolderGroups(rows, counts)`, `emptyFolderIds(rows, occupied)`,
`folderKey(name)`, `embeddedSources(actor, collection)`, `isCachedSpell(doc)`,
`singletonNotes(actorData)`, `SYNC_SCOPE_LABEL`, `MODULE_VERSION`; report
fields `foldersMerged`, `foldersPruned`, `notes[{actor, note}]`,
`embeddedRepaired`, per-actor `items.repaired` / `items.refused`;
`report.sync` gains `trigger`, `stamp`, `merged`, `version`. `SYNC_SCOPES` and the
`scope` option are gone.

New in 1.4: `docDiff(before, after)`, `deepEqual`, `repairIdentifiers(actorData)`,
`slugifyIdentifier(text)`, `tagsOf(actor)`, `decorateDirectory(root, actors)`,
`folderCounts(rows)`; `importPayload` options `colorFolders`, `repairIdentifiers`;
report fields `foldersStyled`, `repaired`, `unchanged`, and `changed` on every
`updated` row.

```js
const api = game.modules.get("waluipedia-mass-import").api;  // also globalThis.waluipedia_mass_import
await api.exportAllActors({ download: true, folderId: null, types: null });
await api.exportToDataFolder({ dir: "npc/waluipedia/midlands", tree: true, combined: true, folderId: null, types: [] });
await api.importFile(file, options);
await api.importFromUrl("https://raw.githubusercontent.com/mikegent01/bik/gh-pages/Reputation-Matrix2/actors/cast/import.json", options);
await api.importFromDataPath("npc/waluipedia/cast", { folderMode: "dirs", ...options });   // a .json or a directory
await api.importPayload(jsonObject, options);           // the workhorse
api.openImportDialog({ url: "npc/waluipedia/cast" });     // pre-filled dialog (review table included)
api.KNOWN_PACKETS;                                        // the repo packets the dropdown lists
await api.syncFromWaluipedia({ review: false, options: { dryRun: false } });  // everything (v1.5); returns the report (+ report.changes, report.sync) or null
await api.autoSync({ delay: 0 });                         // what the ready hook does: sync only if the published packet changed
await api.tidyFolders({ dryRun: true });                  // { foldersMerged, foldersPruned } — what a tidy would do
api.syncCandidates(api.syncSettings());                   // pure: the three places Sync will look, in order
await api.loadManifest(url, { folder: "Players" });       // a manifest.json + the actor files it lists → a payload
// pure helpers, unit-tested: api.assembleDirectory(files, {base, folderMode}), api.buildPlan(raw, {actors, rootFolder}),
// api.applyPlanEdits(raw, plan, edits), api.exportTree(payload, {dir, combined, tree}), api.loadDataPath(path)
```

The result object: `{ created, updated, skipped, failed, foldersCreated, missingImages, dryRun, meta, source, files, ignored }`
— plus, from Sync, `changes` (one row per actor: `status`, `notes[]`, `levelUp`, `folder`) and `sync` (`used`, `attempts`, `info`, `exportedAt`, `world`, `trigger`, `stamp`, `merged`, `version`).

Macros (ready to paste into a script macro) live in `macros/`:
`export-all-actors.js` (works even without the module — falls back to inline
code that still records folder paths), `export-to-data-folder.js`,
`import-all-actors.js`, `import-from-data-folder.js`,
`import-peachs-castle-955.js`, `import-bowsers-castle-1035.js`,
`sync-from-waluipedia.js`.

## The session loop with `tools/foundry-bridge.py`

```
Foundry  --Export all-->  <world>-all-actors.json
                            │
                            ▼  python3 tools/foundry-bridge.py split <world>-all-actors.json --out Reputation-Matrix2/actors/worlds/<world> --prune
                       one file per actor, directories = folders, manifest.json
                            │
                            ▼  edit JSON by hand / python3 tools/foundry-bridge.py apply changes.json <dir> --write
                            ▼  python3 tools/foundry-bridge.py link-images <dir> --write      (portraits from the repo)
                            ▼  python3 tools/foundry-bridge.py check <dir>
                            │
                            ▼  python3 tools/foundry-bridge.py combine <dir> --out <dir>/import.json --world <world>
                            ▼  python3 tools/foundry-bridge.py install-images <dir> --foundry-data <FoundryData>   (copies the PNGs)
                            │
Foundry  <--Import--------  import.json  (file, GitHub raw URL, Data path)
                            — or the split directory itself, linked into Data by
                              python3 tools/foundry-studio.py link  (subfolders → folders)
```

Commit the split tree at the end of every session; the next import finds every
actor by `_id` and updates it in place. The live mirrors live under
[`Reputation-Matrix2/actors/worlds/`](../../actors/worlds/README.md) — the
`midlands` world is already split there (136 actors). `link-images` touches
only placeholder images and missing `portraits/…` paths; GM uploads it cannot
see (`npc/…`, `player/…`) are listed and left alone unless `--replace-unknown`.

Tested against a fake Foundry (including a fake Data folder with
`FilePicker.browse / createDirectory / upload`) by
`tools/tests/test-mass-import-module.mjs`;
point it at a real export to exercise the whole thing:
`WMI_EXPORT=midlands-all-actors.json node tools/tests/test-mass-import-module.mjs`
(136 actors import, re-import updates all 136 and creates nothing).
